<?php
set_include_path("models");
require_once "Autoload.php";
 ?>
<!Doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Conversas Quentes | Aplicativo de conversa</title>
	<?php
	$add = new Add_link_files();

	$imports = [
			'sheets' 		 => array('bootstrap.min','configs','fontConfigs','design','ico/demo-files/demo','materialize'),
			'jspservice' => array('jquery','tools','materialize')
		];


	$rollBack = ( !isset($_REQUEST['apps_cq'] )  ? '' : 'rollback' );
	$add->import_styles($imports['sheets'], $rollBack, "tpl_style");
	$add->import_styles($imports['jspservice'], $rollBack, "tpl_script");

	 ?>
</head>
<body>



		<div class="centralizeCQ" id="container_apps_cq">
			<section class="lines" id="topo_cq">
				<nav class="lines" id="menu">
					<ul>
						<a href="/cq/" id="home"><li><i class="icon icon-home iconCQ"></i></li></a>
						<a href="/cq/conversas"><li><i class="icon icon-bubbles2 iconCQ"></i></li></a>
						<a href="/cq/usuarios"><li><i class="icon icon-users iconCQ"></i></li></a>
					</ul>
				</nav>
			</section>

			<section class="lines" id="content_cq">
				<?php
					$page = new Page();
					$page->getPageActive();
				 ?>
			</section>
		</div>
		<div id="letfInfo">
			<div class="span5" id="messageBox">
				<section class="centralizeCQ infol" id="messages">
					<legend class="cqname">Conversas Quentes</legend>
					<article class="lines"><span class="msg">Ola Amigos</span></article>
					<article class="lines"><span class="msg">Bem vindos a nova plataforma de mensagens </span></article>
					<article class="lines"><span class="msg">Boas Interações e muita conversa</span></article>
					<article class="lines"><span class="msg">Mboura participar</span></article>
				</section>
			</div>
		</div>
	<footer class="lines footer" id="rodape_cq">Developres by Masiry Link Mtecnology.com | Versão Demo 1.0</footer>
</body>
</html>
