$(function(){

    $(":button").attr("type","submit");
    $("form").submit(function(){
        
       return false; 
    })
    .keypress(function(){;
        $(".notific").fadeIn("fast").empty().text("Escrevendo...");
    })
    .focusout(function(){
       $(".notific").empty().fadeOut("slow");
    });
   
   $.ajaxSetup({
      type:       "POST",
      url:        'APP/application.php',
      error:      '',
      befereSend: ''
   });
      
      function loadAjax( load, boxAppend ){
         $.ajax({
         data:     load,
         success:  function( feed ){ $("."+boxAppend).append( feed );   }  
      });
      }
   
   loadAjax( "communicate=allMessages", "messages"  );
   
   
   function sendOneMessage( data_configs ){
      $.ajax({
         data:     data_configs,
         success:  function( feedbackBrowser ){
           if( feedbackBrowser != '1' ){
              $("#messages").append( feedbackBrowser );
           }
         },
         complete: function(){
            $("#boxComments").val('');
         }
      });
   }
   
   $("form[name=comment]").submit(function(){
      comments = $(this).serialize()+"&communicate=commentUser";
      sendOneMessage(comments);
   });
   
   
   $("#container_apps_cq").height($(window).height()-"110");
   $("#messages").height($(window).height()-"350").css("overflow-x","hidden");
   $(window).resize(function(){
      $("#container_apps_cq").height($(window).height()-"110");
      $("#messages").height($(window).height()-"350");
   });
   
});
