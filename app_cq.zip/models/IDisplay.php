<?php

	interface IDisplay
	{
		public function callDisplay();

	}
