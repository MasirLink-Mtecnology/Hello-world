<?php
class Messages extends ManipularBD
{
	protected $table = "conversations";
	private $urlPages	 = "../vews/tpl/pages/";
	public function create( Array $parametros ){
		$adapterInstace = self::getConnection();

		$c['ip_user']				 	= $_SERVER['REMOTE_ADDR'];
		$c['messages']			 	= filter_input(INPUT_POST,'user_comment',FILTER_SANITIZE_SPECIAL_CHARS);
		$c['data_messages'] 	= date("Y-m-d H:i:s");

		if( in_array( '', $c ) ):
			echo "1";
		else:

			$k = implode( ", ", array_keys( $c ) );
			$v = "'".implode( "', '",array_values( $c ) )."'";

			$query  = "INSERT INTO {$this->table} ( $k ) VALUES ( $v )";

			try{

				$create = $adapterInstace->prepare( $query );
				$create->bindValue( ":$k", $v, PDO :: PARAM_STR );
				$create->execute();
				if( $create->rowCount() >= 1 ):
					$idMessage =  self::getConnection()->lastInsertId();
					$lastMessage[] = parent::listar(" WHERE id = '$idMessage' ");
					$tplPages = file_get_contents( $this->urlPages."message.html" );
					echo str_replace( [ '*message*','*id_user*' ], [ $lastMessage[0]->messages, $lastMessage[0]->ip_user ], $tplPages );
				endif;

		}catch( Exception $e ){
				echo "Erro Ao criar: ".$e->getMessage();
		}

	endif;
	}

	public function listarTodos(){
		$listAllMessages = parent::listarTodos();
		if( isset( $listAllMessages ) ):

		$allMessage = new ArrayIterator($listAllMessages);
		$tplPages = file_get_contents( $this->urlPages."message.html" );

		while( $allMessage->valid() ):
			$styles = ( $allMessage->current()->ip_user == $_SERVER['REMOTE_ADDR'] ? 'background:#fbbb3d;color:#363e4d;float:right !important' : 'nostyle' );
			$stylesDetails = ( $allMessage->current()->ip_user == $_SERVER['REMOTE_ADDR'] ? 'text-align:right; margin:-6px 0px 0px -8px !important;' : 'nostyle' );
			echo str_replace( [ '*message*','*id_user*', '*styleformat*', '*styleformatDetails*' ], [ $allMessage->current()->messages, $allMessage->current()->ip_user, $styles, $stylesDetails ], $tplPages );
			$allMessage->next();
		endwhile;

	else:
		echo "No Messages";
	endif;
	}




	public function update( Array $parametros ){

	}
}
