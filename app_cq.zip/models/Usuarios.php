<?php
class Usuarios extends ManipularBD
{
	protected $table = "conversations";
	private $urlPages	 = "../vews/tpl/pages/";

	public function create( Array $parametros ){

	}

	public function update( Array $parametros ){

	}

	public function listarTodos(){
		$listAllMessages = parent::listarTodos();
		if( isset( $listAllMessages ) ):

		$allMessage = new ArrayIterator($listAllMessages);
		$tplPages = file_get_contents( $this->urlPages."message.html" );

		while( $allMessage->valid() ):
			$styles = ( $allMessage->current()->ip_user == $_SERVER['REMOTE_ADDR'] ? 'background:#fbbb3d;color:#363e4d;float:right !important' : 'nostyle' );
			$stylesDetails = ( $allMessage->current()->ip_user == $_SERVER['REMOTE_ADDR'] ? 'text-align:right; margin:-6px 0px 0px -8px !important;' : 'nostyle' );
			echo str_replace( [ '*message*','*id_user*', '*styleformat*', '*styleformatDetails*' ], [ $allMessage->current()->messages, $allMessage->current()->ip_user, $styles, $stylesDetails ], $tplPages );
			$allMessage->next();
		endwhile;

	else:
		echo "No Messages";
	endif;
	}
}
