<?php
 class Add_link_files implements IDisplay{
	private $baseCss = "imports";
	private $urlDeseign	 = "vews/tpl/designs/";

	 public static function smartRollback()
	 {

		$urlRequest = !isset( $_REQUEST['apps_cq'] ) ? '' : substr_count( $_REQUEST['apps_cq'], "/" ) ;
		for( $run = 0; $run < $urlRequest; $run++ ):	$rollback[] = '../';	endfor;
		return ( isset( $rollback ) ? implode( '',$rollback ) : '' );

	}

	public function import_styles( Array $sheets, $path = null, $template )
	{

		if( !is_array( $sheets ) )
			return false;

		else
			$this->sheets 	= $sheets;
			$this->path 		= $path;
			$this->template = $template;
			$this->callDisplay();

	}



	public function callDisplay()
	{

		$pull 		= ( $this->path == 'rollback' ? self::smartRollback() :( $this->path == 'rollbackDash' ? '../' : '' ) );
		$tplStyle = file_get_contents( $this->urlDeseign.$this->template.".html" );
		foreach( $this->sheets as $links ):
			echo str_replace( [ '*path*','*target*' ], [ $pull, $links ], $tplStyle );
		endforeach;

	}


 }
