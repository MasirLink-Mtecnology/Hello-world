<?php
	interface IConnection
	{
		public static function getConnection();
	}
