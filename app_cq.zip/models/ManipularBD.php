<?php
abstract class ManipularBD extends Conversas_Quentes_DB_Connection
{
	protected $table;
	protected $id;

	public function setTable( $table ){
		$this->table = $table;
	}

	public function getTable(){
		return $this->table;
	}

	public function setId( $id ){
		$this->id = $id;
	}

	public function getId(){
		return $this->id;
	}
	abstract public function create( Array $post );
	abstract public function update( Array $post );


	public function listarTodos(){
		$adapterInstace = self::getConnection();
		$query = "SELECT * FROM {$this->table}";

		try{

			$listar = $adapterInstace->prepare( $query );
			$listar->execute();
			if( $listar->rowCount() > 0 )
			return $listar->fetchAll( PDO :: FETCH_OBJ );

		}catch( Exception $e ){
			echo "Erro Ao listar: ".$e->getMessage();
		}

	}


	public function listar( $cond = null ){
		$adapterInstace = self::getConnection();
		$query = "SELECT * FROM {$this->table} {$cond}";

		try{

			$listar = $adapterInstace->prepare( $query );
			$listar->execute();
			if( $listar->rowCount() == 1 )
			return $listar->fetch( PDO :: FETCH_OBJ );

		}catch( Exception $e ){
			echo "Erro Ao listar: ".$e->getMessage();
		}

	}











}
