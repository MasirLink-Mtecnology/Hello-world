<?php
function __autoload( $file )
{

	if( is_string( $file ) )
		require_once $file.".php";
	else
		return false;

}
