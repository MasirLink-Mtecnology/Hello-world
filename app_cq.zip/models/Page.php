<?php
class Page
{

	public function getPageActive()
	{
		set_include_path("vews/tpl/pages/");
		$pageExists = ( isset($_GET['apps_cq']) && ( $_GET['apps_cq'] == "conversas" || $_GET['apps_cq'] == "usuarios" ) ? $_GET['apps_cq'] : "home" );
		switch( $pageExists ):
			case "conversas":
				__autoload( $pageExists );
			break;

			case "usuarios":
				__autoload( $pageExists);
			break;
				default:
					__autoload( "home" );

		endswitch;

	}


}
