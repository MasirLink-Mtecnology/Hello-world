<?php
abstract class Conversas_Quentes_DB_Connection implements IConnection
{
	protected static $instance;

	public static function getConnection()
	{

		try{

			if( !isset( self::$instance ) ):

				$dsn = "mysql:host=localhost;dbname=ango_app_cq";
				self::$instance = new PDO( $dsn, "root", '' );
				self::$instance->setAttribute( PDO :: ATTR_ERRMODE, PDO :: ERRMODE_EXCEPTION );

			endif;
			return self::$instance;

		}catch( PDOException $e ){
			echo "Erro ao conectar ".$e->getMessage();
		}


	}

}
