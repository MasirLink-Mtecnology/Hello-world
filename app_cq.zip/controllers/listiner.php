<?php
ob_start();
session_start();

	require_once "../models/Autoload.php";
	$communicate = filter_input(INPUT_POST,'communicate',FILTER_SANITIZE_SPECIAL_CHARS);
	switch($communicate):
	case "commentUser":
		$newMessage = new Messages();
		$newMessage->create( $_POST );
	break;

	case "allMessages":
		$newMessage = new Messages();
		$newMessage->listarTodos();
	break;

	default:
		echo "Erro de comunicacao";
	endswitch;
