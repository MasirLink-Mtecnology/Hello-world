<div class="container">
	<section class="span8 allDatas" id="allUser">
		<legend>
			<p>Usúarios Ativos</p>
			<aside class="seps"></aside>
		</legend>
		<article class="lines user">
			<i class="icon icon-user iUser"></i>
			<span class="dadosUser"><?php echo $_SERVER['REMOTE_ADDR']; ?></user>
				<ul>
					<li>Mensagens: 0</li>
					<li>Conversar: 0</li>
				</ul>
		</article>
	</section>
</div>
