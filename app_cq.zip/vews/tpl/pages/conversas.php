<div class="container">
	<section class="span8 allDatas" id="allUser">
		<legend>
			<p>Participe das conversas</p>
			<aside class="seps"></aside>
		</legend>

		<div class=" waves-effect waves-light centralizeCQ" id="newTalk">Criar Debate</div>
	</section>
</div>
