<div class="container">
	<section class="span8 allDatas" id="allMessages">
		<legend>
			<p>Participe nesta conversa</p>
			<aside class="seps"></aside>
		</legend>
		<div class="span8" id="messageBox">
			<section class="centralizeCQ messages" id="messages">
                <!-- RECEBE MENSAGENS-->
			</section>
		</div>
		<form name="comment" method="post" action="" class="span8" id="comments">
			<span class="lines notific"></span>
			<textarea name="user_comment" class="centralizeCQ" id="boxComments" placeholder="Conversar..."></textarea>
			<input type="button" class="iconsend icon" value="rocket">
		</form>
	</section>

</div>
